import { useMemo, useState } from 'react';
import { Crosshair, LocateFixed, RotateCcw, Ruler, ScanLine, Target, TriangleAlert } from 'lucide-react';
import { type FormEvent, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

type Point = { x: number; y: number };
type Solution = {
  distance: number;
  azimuth: number;
  dx: number;
  dy: number;
  player: Point;
  target: Point;
};

const EXAMPLE = { scale: '100', player: 'C4', target: 'F7' };

function parseCoordinate(value: string): Point | null {
  const normalized = value.trim().toUpperCase().replace(/,/g, '.');
  const match = normalized.match(
    /^([A-Z])(?:\s*\.\s*(\d+(?:\.\d+)?))?\s+(\d+(?:\.\d+)?)$/,
  ) ?? normalized.match(
    /^([A-Z])(?:\s*\.\s*(\d+(?:\.\d+)?))?(\d+(?:\.\d+)?)$/,
  );
  if (!match) return null;
  const [, letter, letterFraction, numberPart] = match;
  const baseY = letter.charCodeAt(0) - 65 + 1;
  const y = baseY - 1 + (letterFraction ? Number(`0.${letterFraction}`) : 0.5);
  const rawX = Number(numberPart);
  const x = Number.isInteger(rawX) ? rawX - 0.5 : rawX;
  if (!Number.isFinite(x) || !Number.isFinite(y) || x < 0 || y < 0) return null;
  return { x, y };
}

function calculate(scale: string, player: string, target: string): Solution | null {
  const meters = Number(scale.replace(',', '.'));
  const from = parseCoordinate(player);
  const to = parseCoordinate(target);
  if (!Number.isFinite(meters) || meters <= 0 || !from || !to) return null;
  const dx = to.x - from.x;
  const dy = to.y - from.y;
  const distance = Math.sqrt(dx * dx + dy * dy) * meters;
  const azimuth = (Math.atan2(dx, -dy) * 180 / Math.PI + 360) % 360;
  return { distance, azimuth, dx, dy, player: from, target: to };
}

function FieldLabel({ children, hint }: { children: ReactNode; hint?: string }) {
  return (
    <div className="mb-2 flex items-baseline justify-between gap-2">
      <label className="text-[11px] font-bold uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">{children}</label>
      {hint && <span className="font-mono text-[10px] text-[hsl(var(--muted-foreground))]">{hint}</span>}
    </div>
  );
}

function CoordinateInput({
  label, value, onChange, marker, invalid,
}: { label: string; value: string; onChange: (value: string) => void; marker: 'player' | 'target'; invalid: boolean }) {
  return (
    <div className="animate-sweep">
      <FieldLabel hint={marker === 'player' ? 'ĐIỂM GỐC' : 'ĐIỂM ĐẾN'}>{label}</FieldLabel>
      <div className={`relative flex items-center rounded-md border-2 transition-colors ${invalid ? 'border-[hsl(var(--destructive))] bg-[hsl(var(--destructive)/.08)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--input))] focus-within:border-[hsl(var(--primary))]'}`}>
        {marker === 'player' ? <LocateFixed className="ml-3 h-4 w-4 text-[hsl(var(--primary))]" /> : <Target className="ml-3 h-4 w-4 text-[hsl(var(--accent))]" />}
        <input
          data-testid={`input-${marker}-position`}
          value={value}
          onChange={(event) => onChange(event.target.value)}
           placeholder={marker === 'player' ? 'Ví dụ: C4' : 'Ví dụ: F7'}
          aria-label={label}
          spellCheck={false}
          className="w-full bg-transparent px-3 py-3 font-mono text-base font-bold uppercase tracking-[.08em] text-[hsl(var(--foreground))] outline-none placeholder:font-sans placeholder:font-normal placeholder:tracking-normal placeholder:text-[hsl(var(--muted-foreground))]"
        />
        <span className={`mr-3 h-2 w-2 rounded-full ${marker === 'player' ? 'bg-[hsl(var(--primary))]' : 'bg-[hsl(var(--accent))]'}`} />
      </div>
       {invalid && <p data-testid={`error-${marker}-position`} className="mt-1 text-[11px] font-medium text-[hsl(var(--destructive))]">Nhập dạng A1 hoặc C.5 4.5</p>}
    </div>
  );
}

function MiniRadar({ solution }: { solution: Solution | null }) {
  const angle = solution?.azimuth ?? 0;
  return (
    <div className="relative aspect-square w-full max-w-[178px] overflow-hidden rounded-full border border-[hsl(var(--primary)/.42)] bg-[radial-gradient(circle,hsl(var(--primary)/.11),transparent_62%),hsl(224_32%_8%)]">
      <div className="absolute inset-[14%] rounded-full border border-[hsl(var(--primary)/.2)]" />
      <div className="absolute inset-[28%] rounded-full border border-[hsl(var(--primary)/.18)]" />
      <div className="absolute left-1/2 top-0 h-full w-px bg-[hsl(var(--primary)/.18)]" />
      <div className="absolute left-0 top-1/2 h-px w-full bg-[hsl(var(--primary)/.18)]" />
      <div className="absolute left-1/2 top-1/2 h-[41%] w-[2px] origin-bottom bg-[hsl(var(--primary))] shadow-[0_0_12px_hsl(var(--primary)/.5)]" style={{ transform: `translateX(-50%) rotate(${angle}deg)` }} />
      <div className="absolute left-1/2 top-1/2 h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[hsl(var(--accent))] ring-4 ring-[hsl(var(--accent)/.18)]" />
      <span className="absolute left-1/2 top-2 -translate-x-1/2 font-mono text-[9px] font-bold text-[hsl(var(--primary))]">BẮC</span>
      <span className="absolute bottom-2 left-1/2 -translate-x-1/2 font-mono text-[9px] text-[hsl(var(--muted-foreground))]">NAM</span>
      <span className="absolute left-2 top-1/2 -translate-y-1/2 font-mono text-[9px] text-[hsl(var(--muted-foreground))]">TÂY</span>
      <span className="absolute right-2 top-1/2 -translate-y-1/2 font-mono text-[9px] text-[hsl(var(--muted-foreground))]">ĐÔNG</span>
    </div>
  );
}

function CoordinateMap({ solution }: { solution: Solution }) {
  const width = 340;
  const height = 216;
  const left = 38;
  const right = width - 18;
  const top = 22;
  const bottom = height - 32;
  const xMin = Math.min(0, Math.floor(solution.player.x), Math.floor(solution.target.x));
  const yMin = Math.min(0, Math.floor(solution.player.y), Math.floor(solution.target.y));
  const xMax = Math.max(1, Math.ceil(solution.player.x + 1), Math.ceil(solution.target.x + 1));
  const yMax = Math.max(1, Math.ceil(solution.player.y + 1), Math.ceil(solution.target.y + 1));
  const xRange = Math.max(1, xMax - xMin);
  const yRange = Math.max(1, yMax - yMin);
  const toSvgX = (value: number) => left + ((value - xMin) / xRange) * (right - left);
  const toSvgY = (value: number) => top + ((value - yMin) / yRange) * (bottom - top);
  const playerX = toSvgX(solution.player.x);
  const playerY = toSvgY(solution.player.y);
  const targetX = toSvgX(solution.target.x);
  const targetY = toSvgY(solution.target.y);
  const xTicks = Array.from({ length: xRange + 1 }, (_, index) => xMin + index);
  const yTicks = Array.from({ length: yRange + 1 }, (_, index) => yMin + index);

  return (
    <div className="mb-5 overflow-hidden rounded-md border border-[hsl(var(--border))] bg-[hsl(var(--background)/.38)] p-3">
      <div className="mb-2 flex items-center justify-between">
        <p className="font-mono text-[10px] font-bold uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">HỆ TRỤC TỌA ĐỘ</p>
        <p className="font-mono text-[10px] uppercase tracking-[.1em] text-[hsl(var(--muted-foreground))]">X → · Y ↓</p>
      </div>
      <svg
        data-testid="coordinate-map"
        viewBox={`0 0 ${width} ${height}`}
        role="img"
        aria-label="Sơ đồ hệ trục tọa độ với đường nối giữa vị trí xe và mục tiêu"
        className="h-auto w-full"
      >
        <defs>
          <marker id="axis-arrow" viewBox="0 0 8 8" refX="7" refY="4" markerWidth="6" markerHeight="6" orient="auto">
            <path d="M 0 0 L 8 4 L 0 8 z" fill="hsl(var(--muted-foreground))" />
          </marker>
          <filter id="point-glow" x="-100%" y="-100%" width="300%" height="300%">
            <feGaussianBlur stdDeviation="2.5" result="blur" />
            <feMerge>
              <feMergeNode in="blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>

        {xTicks.map((tick) => {
          const x = toSvgX(tick);
          return (
            <g key={`x-${tick}`}>
              <line x1={x} y1={top} x2={x} y2={bottom} stroke="hsl(var(--border))" strokeOpacity="0.5" strokeDasharray="2 4" />
              <text x={x} y={height - 12} textAnchor="middle" fill="hsl(var(--muted-foreground))" fontSize="9" fontFamily="Space Mono, monospace">{tick}</text>
            </g>
          );
        })}
        {yTicks.map((tick) => {
          const y = toSvgY(tick);
          return (
            <g key={`y-${tick}`}>
              <line x1={left} y1={y} x2={right} y2={y} stroke="hsl(var(--border))" strokeOpacity="0.5" strokeDasharray="2 4" />
              <text x={left - 10} y={y + 3} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="9" fontFamily="Space Mono, monospace">{tick}</text>
            </g>
          );
        })}

        <line x1={left} y1={top} x2={right + 5} y2={top} stroke="hsl(var(--muted-foreground))" strokeOpacity="0.7" markerEnd="url(#axis-arrow)" />
        <line x1={left} y1={top} x2={left} y2={bottom + 5} stroke="hsl(var(--muted-foreground))" strokeOpacity="0.7" markerEnd="url(#axis-arrow)" />
        <text x={right + 2} y={top - 8} textAnchor="end" fill="hsl(var(--muted-foreground))" fontSize="9" fontFamily="Space Mono, monospace">X</text>
        <text x={left - 5} y={bottom + 23} textAnchor="middle" fill="hsl(var(--muted-foreground))" fontSize="9" fontFamily="Space Mono, monospace">Y</text>

        <line x1={playerX} y1={playerY} x2={targetX} y2={targetY} stroke="hsl(var(--primary))" strokeWidth="2.5" strokeDasharray="6 4" />
        <circle cx={playerX} cy={playerY} r="7" fill="hsl(var(--primary))" fillOpacity="0.18" filter="url(#point-glow)" />
        <circle cx={playerX} cy={playerY} r="4" fill="hsl(var(--primary))" />
        <circle cx={targetX} cy={targetY} r="7" fill="hsl(var(--accent))" fillOpacity="0.18" filter="url(#point-glow)" />
        <circle cx={targetX} cy={targetY} r="4" fill="hsl(var(--accent))" />
        <text x={playerX + 9} y={playerY - 9} fill="hsl(var(--primary))" fontSize="10" fontWeight="700" fontFamily="Space Mono, monospace">XE BẠN</text>
        <text x={targetX + 9} y={targetY - 9} fill="hsl(var(--accent))" fontSize="10" fontWeight="700" fontFamily="Space Mono, monospace">MỤC TIÊU</text>
      </svg>
      <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 font-mono text-[10px] text-[hsl(var(--muted-foreground))]">
        <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-[hsl(var(--primary))]" />Xe bạn</span>
        <span><i className="mr-1 inline-block h-2 w-2 rounded-full bg-[hsl(var(--accent))]" />Mục tiêu</span>
        <span className="text-[hsl(var(--foreground)/.72)]">Đường nét đứt = hướng bắn</span>
      </div>
    </div>
  );
}

function Calculator() {
  const [scale, setScale] = useState('');
  const [player, setPlayer] = useState('');
  const [target, setTarget] = useState('');
  const [hasCalculated, setHasCalculated] = useState(false);
  const playerValid = player.length > 0 && !parseCoordinate(player);
  const targetValid = target.length > 0 && !parseCoordinate(target);
  const solution = useMemo(() => calculate(scale, player, target), [scale, player, target]);
  const hasMissing = !scale.trim() || !player.trim() || !target.trim();
  const canCalculate = !hasMissing && !playerValid && !targetValid && Number(scale.replace(',', '.')) > 0;

  const useExample = () => {
    setScale(EXAMPLE.scale);
    setPlayer(EXAMPLE.player);
    setTarget(EXAMPLE.target);
    setHasCalculated(false);
  };
  const reset = () => {
    setScale('');
    setPlayer('');
    setTarget('');
    setHasCalculated(false);
  };
  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setHasCalculated(true);
  };
  const showResult = hasCalculated && canCalculate && solution;

  return (
    <main className="noise min-h-[100dvh] overflow-hidden px-4 pb-10 pt-5 sm:px-8">
      <div className="mx-auto max-w-5xl">
        <header className="mb-7 flex items-start justify-between gap-4 animate-rise">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[hsl(var(--primary))] text-[hsl(var(--primary-foreground))]">
                <Crosshair className="h-5 w-5" strokeWidth={2.5} />
              </div>
              <span className="font-mono text-[10px] font-bold uppercase tracking-[.18em] text-[hsl(var(--primary))]">WT // FIELD TOOL 01</span>
            </div>
            <h1 className="max-w-[15ch] text-3xl font-bold leading-[.95] tracking-[-.045em] text-[hsl(var(--foreground))] sm:text-5xl">Tính phần tử<br /><span className="text-[hsl(var(--primary))]">bắn.</span></h1>
            <p className="mt-3 max-w-sm text-sm leading-relaxed text-[hsl(var(--muted-foreground))]">Khoảng cách và hướng bắn, đọc trong một nhịp mắt.</p>
          </div>
          <div className="mt-1 hidden text-right sm:block">
            <p className="font-mono text-[10px] uppercase tracking-[.16em] text-[hsl(var(--muted-foreground))]">TRẠNG THÁI</p>
            <p className="mt-1 flex items-center justify-end gap-2 font-mono text-xs font-bold text-[hsl(var(--primary))]"><span className="h-1.5 w-1.5 rounded-full bg-[hsl(var(--primary))] animate-radar" /> SẴN SÀNG</p>
          </div>
        </header>

        <div className="grid gap-4 lg:grid-cols-[minmax(0,1fr)_minmax(300px,.72fr)] lg:items-start">
          <section className="rounded-lg border border-[hsl(var(--border))] bg-[hsl(var(--card)/.9)] p-4 shadow-[var(--shadow-md)] sm:p-6 animate-rise" style={{ animationDelay: '70ms' }}>
            <div className="mb-5 flex items-center justify-between border-b border-[hsl(var(--border))] pb-4">
              <div>
                 <p className="font-mono text-[10px] font-bold uppercase tracking-[.16em] text-[hsl(var(--primary))]">01 / THÔNG SỐ</p>
                <h2 className="mt-1 text-lg font-bold">Đặt tọa độ trên bản đồ</h2>
                 <p className="mt-1 text-xs text-[hsl(var(--muted-foreground))]">Chữ = trục Y dọc · Số = trục X ngang</p>
              </div>
              <Ruler className="h-5 w-5 text-[hsl(var(--muted-foreground))]" />
            </div>
            <form onSubmit={submit} className="space-y-5">
              <div>
                <FieldLabel hint="m / Ô">Tỉ lệ bản đồ</FieldLabel>
                <div className="relative flex items-center rounded-md border-2 border-[hsl(var(--border))] bg-[hsl(var(--input))] focus-within:border-[hsl(var(--primary))]">
                  <Ruler className="ml-3 h-4 w-4 text-[hsl(var(--primary))]" />
                  <input data-testid="input-scale" type="text" inputMode="decimal" value={scale} onChange={(event) => setScale(event.target.value)} placeholder="100" aria-label="Tỉ lệ bản đồ" className="w-full bg-transparent px-3 py-3 font-mono text-base font-bold text-[hsl(var(--foreground))] outline-none placeholder:text-[hsl(var(--muted-foreground))]" />
                  <span className="mr-3 whitespace-nowrap font-mono text-[10px] text-[hsl(var(--muted-foreground))]">M / Ô</span>
                </div>
                {hasCalculated && (!scale.trim() || Number(scale.replace(',', '.')) <= 0) && <p className="mt-1 text-[11px] text-[hsl(var(--destructive))]">Cần nhập số mét lớn hơn 0.</p>}
              </div>
              <div className="grid gap-5 sm:grid-cols-2">
                <CoordinateInput label="Vị trí của bạn" value={player} onChange={setPlayer} marker="player" invalid={playerValid} />
                <CoordinateInput label="Vị trí mục tiêu" value={target} onChange={setTarget} marker="target" invalid={targetValid} />
              </div>
              <div className="flex flex-col gap-3 border-t border-[hsl(var(--border))] pt-5 sm:flex-row">
                <button data-testid="button-calculate" type="submit" className="group flex min-h-12 flex-1 items-center justify-center gap-2 rounded-md bg-[hsl(var(--primary))] px-5 text-sm font-bold text-[hsl(var(--primary-foreground))] transition-transform hover:-translate-y-0.5 active:translate-y-0 disabled:cursor-not-allowed disabled:opacity-50" disabled={hasMissing}>
                  <ScanLine className="h-4 w-4 transition-transform group-hover:rotate-12" /> TÍNH PHẦN TỬ
                </button>
                <div className="flex gap-3">
                  <button data-testid="button-example" type="button" onClick={useExample} className="min-h-12 flex-1 rounded-md border border-[hsl(var(--border))] px-4 text-xs font-bold text-[hsl(var(--foreground))] transition-colors hover:border-[hsl(var(--primary))] hover:text-[hsl(var(--primary))]">DÙNG MẪU</button>
                  <button data-testid="button-reset" type="button" onClick={reset} className="flex min-h-12 w-12 items-center justify-center rounded-md border border-[hsl(var(--border))] text-[hsl(var(--muted-foreground))] transition-colors hover:border-[hsl(var(--accent))] hover:text-[hsl(var(--accent))]" aria-label="Đặt lại biểu mẫu"><RotateCcw className="h-4 w-4" /></button>
                </div>
              </div>
            </form>
          </section>

          <section className={`relative overflow-hidden rounded-lg border p-4 shadow-[var(--shadow-md)] sm:p-6 ${showResult ? 'border-[hsl(var(--primary)/.55)] bg-[hsl(var(--primary)/.08)]' : 'border-[hsl(var(--border))] bg-[hsl(var(--card)/.72)]'} animate-rise`} style={{ animationDelay: '140ms' }}>
            <div className="mb-5 flex items-start justify-between">
              <div>
                <p className={`font-mono text-[10px] font-bold uppercase tracking-[.16em] ${showResult ? 'text-[hsl(var(--primary))]' : 'text-[hsl(var(--muted-foreground))]'}`}>02 / KẾT QUẢ</p>
                <h2 className="mt-1 text-lg font-bold">Lệnh khai hỏa</h2>
              </div>
              <div className="rounded-md border border-[hsl(var(--border))] p-2"><Crosshair className={`h-5 w-5 ${showResult ? 'text-[hsl(var(--primary))]' : 'text-[hsl(var(--muted-foreground))]'}`} /></div>
            </div>
            {showResult ? (
              <div data-testid="result-solution" className="animate-rise">
                <div className="mb-5 grid grid-cols-2 gap-3">
                  <div className="rounded-md border border-[hsl(var(--primary)/.3)] bg-[hsl(var(--background)/.4)] p-4">
                    <p className="font-mono text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">KHOẢNG CÁCH</p>
                    <p data-testid="text-distance" className="mt-2 font-mono text-2xl font-bold tracking-[-.06em] text-[hsl(var(--primary))]">{Math.round(solution.distance).toLocaleString('vi-VN')}<span className="ml-1 text-xs tracking-normal">m</span></p>
                  </div>
                  <div className="rounded-md border border-[hsl(var(--accent)/.35)] bg-[hsl(var(--background)/.4)] p-4">
                    <p className="font-mono text-[10px] uppercase tracking-[.12em] text-[hsl(var(--muted-foreground))]">GÓC PHƯƠNG VỊ</p>
                    <p data-testid="text-azimuth" className="mt-2 font-mono text-2xl font-bold tracking-[-.06em] text-[hsl(var(--accent))]">{Math.round(solution.azimuth)}<span className="ml-1 text-xs tracking-normal">°</span></p>
                  </div>
                </div>
                 <CoordinateMap solution={solution} />
                <div className="flex items-center gap-4">
                  <MiniRadar solution={solution} />
                  <div className="space-y-2 font-mono text-[10px] text-[hsl(var(--muted-foreground))]">
                    <p><span className="text-[hsl(var(--primary))]">Δ X</span> {solution.dx >= 0 ? '+' : ''}{solution.dx.toFixed(1)} ô</p>
                    <p><span className="text-[hsl(var(--accent))]">Δ Y</span> {solution.dy >= 0 ? '+' : ''}{solution.dy.toFixed(1)} ô</p>
                    <p className="pt-2 font-sans text-xs leading-relaxed text-[hsl(var(--foreground)/.78)]">Giữ hướng bắc làm mốc. Xoay tháp theo góc phương vị.</p>
                  </div>
                </div>
              </div>
            ) : (
              <div data-testid="empty-result" className="flex min-h-[260px] flex-col items-center justify-center border border-dashed border-[hsl(var(--border))] px-5 text-center">
                <div className="mb-4 rounded-full border border-[hsl(var(--border))] p-4"><Crosshair className="h-7 w-7 text-[hsl(var(--muted-foreground))]" /></div>
                <p className="text-sm font-bold text-[hsl(var(--foreground))]">Chưa có phần tử bắn</p>
                <p className="mt-2 max-w-[23ch] text-xs leading-relaxed text-[hsl(var(--muted-foreground))]">Nhập đủ thông số rồi nhấn tính. Không cần mạng.</p>
              </div>
            )}
            {hasCalculated && !canCalculate && !playerValid && !targetValid && <div className="mt-4 flex items-start gap-2 rounded-md bg-[hsl(var(--destructive)/.1)] p-3 text-xs text-[hsl(var(--destructive))]"><TriangleAlert className="mt-0.5 h-4 w-4 shrink-0" /> Kiểm tra lại các trường bắt buộc trước khi khai hỏa.</div>}
          </section>
        </div>
        <footer className="mt-6 flex flex-col gap-2 border-t border-[hsl(var(--border))] pt-4 font-mono text-[10px] uppercase tracking-[.13em] text-[hsl(var(--muted-foreground))] sm:flex-row sm:items-center sm:justify-between animate-rise" style={{ animationDelay: '210ms' }}>
          <span>CALC / OFFLINE / V1.0</span>
          <span>Độ chính xác phụ thuộc vào tọa độ bản đồ</span>
        </footer>
      </div>
    </main>
  );
}

function Router() {
  return (
    <RoutedErrorBoundary>
      <Switch>
        <Route path="/" component={Calculator} />
        <Route component={NotFound} />
      </Switch>
    </RoutedErrorBoundary>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;